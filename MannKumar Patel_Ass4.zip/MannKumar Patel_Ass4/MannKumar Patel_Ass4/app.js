const express = require("express");
const path = require("path");
const { check, validationResult } = require("express-validator");
const mongoose = require("mongoose");

const uri = "mongodb://127.0.0.1:27017/receiptApp";
mongoose.connect(uri).then(() => {
    console.log("connected to db!");
});

const Order = mongoose.model(
    "Order",
    new mongoose.Schema(
        {
            name: String,
            email: String,
            phone: String,
            address: String,
            city: String,
            postal: String,
            province: String,
            product1: Number,
            product2: Number,
            product3: Number,
            sCharges: Number,
            grossAmt: Number,
            taxAmount: Number,
            totalCost: Number,
        },
        { collection: "orders" }
    )
);

const app = express();
const port = 2808;

app.use(express.urlencoded({ extended: false }));

app.use(express.static(path.join(__dirname, "public")));

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

app.get("/", (req, res) => {
    res.render("home");
});

app.post(
    "/receipt",
    [
        check("name", "Please Enter your valid Name").notEmpty(),
        check("email", "Please Enter your valid Email").isEmail(),
        check("phone", "Please Enter your valid Phonenumber").matches(/^\d{3}-\d{3}-\d{4}$/),
        check("address", "Please Enter your current Address").notEmpty(),
        check("city", "Please Enter your City name").notEmpty(),
        check("postal", "Please Enter your Postalcode").matches(/^[A-Z]\d[A-Z]\s\d[A-Z]\d$/),
        check("province", "Please Select your Province").notEmpty(),
        check("product1", "Please Enter Sofa Set quantity").isNumeric(),
        check("product2", "Please Enter TV quantity").isNumeric(),
        check("product3", "Please Enter Table quantity").isNumeric(),
    ],
    (req, res) => {
        var name = req.body.name;
        var email = req.body.email;
        var phone = req.body.phone;
        var address = req.body.address;
        var city = req.body.city;
        var postal = req.body.postal;
        var province = req.body.province;
        var product1 = parseInt(req.body.product1);
        var product2 = parseInt(req.body.product2);
        var product3 = parseInt(req.body.product3);

        let errors = validationResult(req);
        console.log(req.body);

        if (!errors.isEmpty()) {
            res.render("home", { errors: errors.array() });
        } else {
            const provinceTax = {
                Ontario: 13,
                NovaScotia: 15,
                NewBrunswick: 15,
                Manitoba: 12,
                Qubec: 15,
                BritishColumbia: 12,
                PrinceEdwardIsland: 15,
                Saskatchewan: 11,
                Alberta: 5,
                NewfoundlandandLabrador: 15,
                NorthwestTerritories: 5,
                Yukon: 5,
                Nunavut: 5
                
            };

            const taxRate = provinceTax[province] || 0;

            var i1Prize = 375;
            var i2Prize = 800;
            var i3Prize = 50;
            var sfee = 5;
            var i1Qnt = product1;
            var i2Qnt = product2;
            var i3Qnt = product3;
            var netAmount = i1Qnt * i1Prize + i2Qnt * i2Prize + i3Qnt * i3Prize + sfee;
            var tax = netAmount * taxRate / 100;
            var netCost = netAmount + tax;

            var newOrder = new Order({
                name: name,
                email: email,
                phone: phone,
                address: address,
                city: city,
                postal: postal,
                province: province,
                product1: product1,
                product2: product2,
                product3: product3,
                sCharges: sfee,
                grossAmt: netAmount,
                taxAmount: tax,
                totalCost: netCost,
            });

            newOrder
                .save()
                .then(function (savedOrder) {
                    console.log("Order saved successfully");
                    res.render("receipt", { order: savedOrder });
                })
                .catch(function (error) {
                    console.log("Error saving order: ", error);
                    res.render("error", {
                        message: "There was an error processing your order. Please try again later.",
                    });
                });
        }
    }
);

// app.get("/alldata", function (req, res) {
//     Order.find({}).exec(function (err, orders) {
//         console.log(err);
//         res.render("alldata", { orders: orders });
//     });
// });

app.get("/alldata", function (req, res) {
    Order.find({})
        .then((orders) => {
            console.log("Retrieved orders:", orders);
            res.render("alldata", { orders: orders });
        })
        .catch((error) => {
            console.error("Error fetching data:", error);
            res.status(500).render("error", { message: "Error fetching data from the database." });
        });
});

app.listen(port, () => {
    console.log(`Click the link to open App in Browser http://localhost:${port}`);
});
